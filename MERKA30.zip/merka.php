<?php

// no direct access
defined('_JEXEC') or die;

class plgContentMerka extends JPlugin
{
    function onContentAfterDisplay( $context, &$article, &$params, $limitstart )
        {
	$positie= $this->params->get('positieN');
	if ($positie == TRUE)
	{
		setlocale(LC_ALL, 'nld_nld','Dutch','be_BE','nl');
		//$crtext= $this->params->get('crtext');
		$crtext= $this->params->get('edit1');
		$dat2 = $this->params->get('startdate');
		$datum=strtotime($dat2);
		$nu =time();
		//$txtkleur = $this->params->get('tekstkleur');

		if($datum <= $nu)  // Datum is voorbij
		{
			return "<p>$crtext</p>";
		}
	}	
	
        }
   function onContentBeforeDisplay( $context, &$article, &$params, $limitstart )
        {
	$positie = $this->params->get('positieV');
	if ($positie == TRUE)
	{
		setlocale(LC_ALL, 'nld_nld','Dutch','be_BE','nl');
		//$crtext= $this->params->get('crtext');
		$crtext= $this->params->get('edit1');
		$dat2 = $this->params->get('startdate');
		$datum=strtotime($dat2);
		$nu =time();
		//$txtkleur = $this->params->get('tekstkleur');

		if($datum <= $nu)  // Datum is voorbij
		{
			return "<p>$crtext</p>";
			
		}
	}	
	
        }
	 public function __construct(& $subject, $config)
        
	{
                parent::__construct($subject, $config);

	                $this->loadLanguage();
        
	}

        

	public function onContentPrepare($context, &$article, &$params, $page=0)
        
	{
               $orig=' {{merka}} ';
                
		$repl=$this->params->get('edit1');             
		$article->text = preg_replace($orig, $repl, $article->text);

                
		return true;
        
	} 
}

?>
